Deps:
pkg install cmake

How to compile:
cd DevIL/DevIL
cmake CMakeLists.txt
make
(or make install)

How to clean up:
cd DevIL/DevIL
rm -f CMakeCache.txt
make clean

Source: https://github.com/martysama0134/libdevil-patched
